use healthcare;

select P.gender, count(T.treatmentID) as Treatment_Count, count(T.claimID) as Claim_Count, 
count(T.treatmentID)/count(T.claimID) as Treatment_to_claim_ratio
from person P join patient P1 on P.personID = P1.patientID
join treatment T on P1.patientID = T.patientID
group by P.gender;