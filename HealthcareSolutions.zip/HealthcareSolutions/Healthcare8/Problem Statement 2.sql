use healthcare;

-- For each city, Find the number of registered people, number of pharmacies, and number of insurance companies.

drop table if exists T1;
drop table if exists T2;
drop table if exists T3;

create table T1(
city varchar(100),
numPharmacy int
);

create table T2(
city varchar(100),
numInsuranceCompany int
);

create table T3(
city varchar(100),
numRegisteredPeople int
);

INSERT INTO T1
SELECT Address.city, COUNT(Pharmacy.pharmacyID) AS numPharmacy
FROM Pharmacy
RIGHT JOIN Address ON Pharmacy.addressID = Address.addressID
GROUP BY city
ORDER BY COUNT(Pharmacy.pharmacyID) DESC;

INSERT INTO T2
SELECT Address.city, COUNT(InsuranceCompany.companyID) as numInsuranceCompany
FROM InsuranceCompany
RIGHT JOIN Address ON InsuranceCompany.addressID = Address.addressID
GROUP BY city
ORDER BY COUNT(InsuranceCompany.companyID) DESC;

INSERT INTO T3
SELECT Address.city, COUNT(Person.personID) as numRegisteredPeople
FROM Person
RIGHT JOIN Address ON Person.addressID = Address.addressID
GROUP BY city
ORDER BY COUNT(Person.personID) DESC;

select T1.city, T3.numRegisteredPeople, T2.numInsuranceCompany, T1.numPharmacy
from T1, T2, T3
where T1.city = T2.city and T2.city = T3.city
order by numRegisteredPeople desc;

-- Optimized query
select city, COALESCE(count(personID),0) as numRegisteredPeople, COALESCE(count(CompanyID),0) as numInsuranceCompany, COALESCE(count(pharmacyID),0) as numPharmacy
from address left join person using(addressID)
left join insurancecompany using(addressID)
left join Pharmacy using(addressID)
group by city
order by numRegisteredPeople desc, numInsuranceCompany desc, numPharmacy desc;
