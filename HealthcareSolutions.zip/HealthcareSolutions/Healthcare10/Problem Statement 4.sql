use healthcare;


create table if not exists PlacesAdded(
		placeID int auto_increment primary key,
        placeName varchar(100),
        placeType varchar(10),
        timeAdded timestamp DEFAULT current_timestamp
    );
    
-- drop table placesAdded;

DELIMITER //
create trigger PopulatedPlacesAdded
before insert
on address
for each row
BEGIN
    IF (new.city not in (select distinct city from address)) THEN 
		insert into placesadded(placeName, placeType)
        values (new.city, "City");
	END IF;
	IF (new.state not in (select distinct state from address)) THEN 
		insert into placesadded(placeName, placeType)
		values (new.state, "State");
	END IF;
END
//
DELIMITER ;

-- drop trigger PopulatedPlacesAdded;

 -- select * from address;

insert into address values(999545,"1st Block Koramangala", "Bangalore","KA","560034");
select * from PlacesAdded;
insert into address values(999546,"Great Road, Downlane", "Britain","CT","6048");
select * from PlacesAdded;