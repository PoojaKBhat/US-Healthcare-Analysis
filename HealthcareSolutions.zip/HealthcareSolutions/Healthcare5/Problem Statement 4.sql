use healthcare;

select pharmacyName, diseaseName,
SUM(CASE
WHEN YEAR(date)=2021 THEN 1 else 0
END) as prescription_count_2021,
SUM(CASE
WHEN YEAR(date)=2022 THEN 1 else 0
END) as prescription_count_2022
from disease join treatment using(diseaseID)
join prescription using(treatmentID)
join pharmacy using (pharmacyID)
WHERE YEAR(date) in (2021,2022)
group by pharmacyName,diseaseName
order by pharmacyName;