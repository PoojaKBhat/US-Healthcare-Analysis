use healthcare;

select d.diseaseName,
sum(CASE
	WHEN p.gender = "FEMALE" THEN 1 
    else 0
END) as female_count,
sum(CASE
	WHEN p.gender = "MALE" THEN 1 
    else 0
END) as male_count,

(CASE
 when sum(CASE when p.gender="FEMALE" THEN 1 else 0 END)=0 THEN 0
 ELSE
	(sum(CASE when p.gender="MALE" then 1 else 0 END))/(sum(CASE when p.gender="FEMALE" then 1 else 0 END))
 END) as male_to_female_ratio

from person p join patient pa on p.personID=pa.patientID
join treatment t on pa.patientID=t.patientID
join disease d on t.diseaseID=d.diseaseID
where year(t.date)=2021
group by d.diseaseName;