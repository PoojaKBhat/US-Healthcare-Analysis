use healthcare;

DELIMITER //
CREATE PROCEDURE GetGenderwiseReport1(IN disease_id INT)
BEGIN
    DECLARE disease_name VARCHAR(255);
    DECLARE number_of_male_treated INT;
    DECLARE number_of_female_treated INT;
    DECLARE more_treated_gender VARCHAR(10);

    -- Get the disease name
    SELECT diseaseName INTO disease_name
    FROM disease
    WHERE diseaseID = disease_id;

    -- Calculate the number of males and females treated for the disease
    SELECT
        SUM(CASE WHEN person.gender = 'Male' THEN 1 ELSE 0 END) AS male_count,
        SUM(CASE WHEN person.gender = 'Female' THEN 1 ELSE 0 END) AS female_count
    INTO number_of_male_treated, number_of_female_treated
    FROM treatment
    JOIN patient ON treatment.patientID = patient.patientID
    join person on patient.patientID=person.personID
    WHERE treatment.diseaseID = disease_id;

    -- Determine the more treated gender
    IF number_of_male_treated > number_of_female_treated THEN
        SET more_treated_gender = 'Male';
    ELSEIF number_of_female_treated > number_of_male_treated THEN
        SET more_treated_gender = 'Female';
    ELSE
        SET more_treated_gender = 'Same';
    END IF;

    -- Return the result
    SELECT disease_name, number_of_male_treated, number_of_female_treated, more_treated_gender;
END
//
DELIMITER ;


CALL GetGenderwiseReport(15);
CALL GetGenderwiseReport(38);
CALL GetGenderwiseReport(39);
CALL GetGenderwiseReport(40);