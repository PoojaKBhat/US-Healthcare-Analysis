use healthcare;

DELIMITER //
CREATE PROCEDURE GetPharmacyMedicineInfo()
BEGIN
    SELECT p.pharmacyID, p.pharmacyName, p.phone, m.productName, k.quantity
    FROM pharmacy p
    JOIN keep k ON p.pharmacyID = k.pharmacyID
    JOIN medicine m ON m.medicineID = k.medicineID;
END //
DELIMITER ;

call GetPharmacyMedicineInfo();