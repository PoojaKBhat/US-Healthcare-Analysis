use healthcare;

select state,
((sum(CASE
WHEN claimID is NULL then 1 else 0 END)/count(treatmentID))*100)
as perc_without_claim
from address join person using(addressID)
join patient on person.personID=patient.patientID
join treatment using(patientID)
group by state;