use healthcare;

DELIMITER //
create function getavg(compname VARCHAR(220)) returns VARCHAR(20) deterministic
begin
		declare avg_bal varchar(20);
	
		select round(avg(c.balance),2) into avg_bal
		from insurancecompany i join insuranceplan i2 on i.companyID = i2.companyID 
		join claim c on c.uin = i2.uin join treatment t on t.claimID = c.claimID
		where year(t.date) = 2022 and i.companyName = compname;
		
		return avg_bal;
end //
DELIMITER ;

select getavg('Star Health and Allied Insurrance Co. Ltd.')