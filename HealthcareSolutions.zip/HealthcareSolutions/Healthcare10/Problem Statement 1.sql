use healthcare;

DELIMITER //
create procedure insurancePlanPerformance(IN companyName varchar(100))
BEGIN
	select IP.planName, count(t.treatmentID) as treatmentCount,
	(select D.diseaseName
	from disease D join treatment T on T.diseaseID=D.diseaseID
	join claim C on C.claimID=T.claimID
	where IP.uin = C.uin
	group by IP.uin, D.diseaseName
	ORDER BY COUNT(*) DESC
	LIMIT 1) as mostClaimedDisease
	from insurancecompany IC left join insuranceplan IP
	on  IC.companyID=IP.companyID
	left join claim C on C.uin=IP.uin
	left join treatment t on C.claimID=t.claimID
	where IC.companyName = companyName
	group by IP.planName, IP.uin
	order by treatmentCount desc;
END
//
DELIMITER ;

CALL insurancePlanPerformance("Aditya Birla Health Insurance Co. Ltd");
CALL insurancePlanPerformance("Bajaj Allianz General Insurance Co. Ltd.�");
CALL insurancePlanPerformance("United India Insurance Co.Ltd.");
CALL insurancePlanPerformance("SBI General Insurance Co.Ltd.");
CALL insurancePlanPerformance("Future Generali India Insurance Company Limited.���");

