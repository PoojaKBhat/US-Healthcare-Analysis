use healthcare;

with prescription_count as
(select pharmacyID ,count(prescriptionID) as prescription_count from prescription
group by pharmacyID)
select a.city, count(Ph.pharmacyID) as pharmacy_count, sum(prescription_count) as total_prescriptions,
(count(Ph.pharmacyID)/sum(prescription_count)) as pharmacy_to_prescription_ratio
from address a join pharmacy Ph on Ph.addressID=a.addressID
join prescription_count on Ph.pharmacyID=prescription_count.pharmacyID
group by a.city
having total_prescriptions>100
order by pharmacy_to_prescription_ratio;