use healthcare;

select diseaseName, city, treatmentCount from
(select diseaseName, city, count(treatmentID) as treatmentCount,
rank() over (partition by diseaseName order by count(treatmentID) desc) as disease_rank
from address join pharmacy using(addressID)
join prescription using(pharmacyID)
join treatment using(treatmentID)
join disease using(diseaseID)
group by city, diseaseName
order by diseaseName asc, treatmentCount desc) as sq
where disease_rank<=3;