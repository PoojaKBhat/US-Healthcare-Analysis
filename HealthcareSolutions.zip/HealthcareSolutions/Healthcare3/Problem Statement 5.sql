use healthcare;

select pharmacyName, sum(quantity) totalQuantity
from address join pharmacy using(addressID)
join prescription using(pharmacyID)
join contain using(prescriptionID)
join medicine using(medicineID)
join treatment using(treatmentID)
where taxCriteria="I" and state="AZ" and year(date)=2021
group by pharmacyName;