use healthcare;

select state, diseaseName, treatment_count,
(CASE
	WHEN most_treated_rank=1 THEN "Most Treated Disease"
    WHEN least_treated_rank=1 THEN "Least Treated Disease"
END) as diseaseStatus from(
select state, diseaseName, count(treatmentID) as treatment_count,
rank() over (partition by state order by count(treatmentID) desc) as most_treated_rank,
rank() over (partition by state order by count(treatmentID)) as least_treated_rank
from address join person using (addressID)
join patient on person.personID = patient.patientID
join treatment using (patientID)
join disease using (diseaseID)
where year(date)=2022
group by diseaseName, state) as sq
where least_treated_rank=1 or most_treated_rank=1
order by state, treatment_count desc;