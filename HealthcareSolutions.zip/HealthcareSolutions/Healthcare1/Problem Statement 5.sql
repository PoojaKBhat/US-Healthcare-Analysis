use healthcare;

select P.pharmacyID, max(medicine_count), min(medicine_count), round(avg(medicine_count),2)
from (select C.prescriptionID,count(C.medicineID) as medicine_count from Contain C group by C.prescriptionID) as counting_medicines
join Prescription P on P.prescriptionID = counting_medicines.prescriptionID
group by P.pharmacyID;