use healthcare;

delimiter //
create procedure most_least_plans(in x int)
begin
	with cte as(
	select i2.planname,count(*) as claim_count,
	row_number () over(order by count(*) desc) as most_claimed,
	row_number() over(order by count(*) asc) as least_claimed
	from insurancecompany i 
	join insuranceplan i2 using(companyid)
	join claim using(uin)
	where i.companyid = x
	group by i2.planName )
	select a.planname as most_claimed,b.planname as least_claimed
	from cte a join cte b on a.most_claimed=b.least_claimed
	where a.most_claimed <=3 or b.least_claimed <=3;
end;
//
delimiter ;

call most_least_plans(6403);