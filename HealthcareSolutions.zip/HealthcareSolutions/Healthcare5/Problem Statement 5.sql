use healthcare;

select companyName,state, claim_count from
(select companyName,state, count(claimID) as claim_count,
rank() over (partition by companyName order by count(claimID) desc) as state_rank
from address join person using(addressID)
join patient on person.personID=patient.patientID
join treatment using(patientID)
join claim using(claimID)
join insuranceplan using(uin)
join insurancecompany using(companyID)
group by companyName,state) as sq
where state_rank=1
order by companyName,state;