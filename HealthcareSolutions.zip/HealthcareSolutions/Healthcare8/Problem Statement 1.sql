use healthcare;

-- For each age(in years), how many patients have gone for treatment?
SELECT (YEAR(NOW()) - YEAR(dob)) as age, COUNT(*) AS numTreatments
FROM Person
JOIN Patient ON Patient.patientID = Person.personID
JOIN Treatment ON Treatment.patientID = Patient.patientID
GROUP BY age
ORDER BY numTreatments DESC;


