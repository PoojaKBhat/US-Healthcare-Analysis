use healthcare;

select K.pharmacyID, count(K.medicineID) as Total_Medicine_Units, sum(M.maxPrice) as Total_Max_Retail_Price,
 round(sum(M.maxPrice - M.maxPrice*(K.discount/100)),2) as Total_Price_after_discount
from keep K join medicine M on K.medicineID = M.medicineID
group by K.pharmacyID
order by K.pharmacyID;