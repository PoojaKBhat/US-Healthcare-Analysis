use healthcare;

DELIMITER //
create procedure topPhrmacy(IN disease_name varchar(100))
BEGIN
	(select pharmacyName from (select ph.pharmacyName as pharmacyName, count(t.patientID) as patientCount, 
	rank() over (order by count(t.patientID) desc) as top_rank
	from pharmacy ph join prescription pr on ph.pharmacyID=pr.pharmacyID
	join treatment t on pr.treatmentID=t.treatmentID
	join disease d on t.diseaseID=d.diseaseID
	where d.diseaseName = disease_name and YEAR(t.date) = 2021
	group by ph.pharmacyName
	order by count(t.patientID) desc) as q1 where top_rank<=3
	UNION ALL
	select pharmacyName from (select ph.pharmacyName as pharmacyName, count(t.patientID) as patientCount, 
	rank() over (order by count(t.patientID) desc) as top_rank
	from pharmacy ph join prescription pr on ph.pharmacyID=pr.pharmacyID
	join treatment t on pr.treatmentID=t.treatmentID
	join disease d on t.diseaseID=d.diseaseID
	where d.diseaseName = disease_name and YEAR(t.date) = 2022
	group by ph.pharmacyName
	order by count(t.patientID) desc) as q2 where top_rank<=3)
	order by pharmacyName;
END
//
DELIMITER ;

call topPhrmacy("Asthma");
call topPhrmacy("Psoriasis");