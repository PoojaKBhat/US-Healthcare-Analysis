use healthcare;

DELIMITER //
create procedure companySetup(IN req_state varchar(20))
BEGIN
	with patientcount as
	(select companyID, count(patientID) as totalPatients
	from claim join treatment using(claimID)
	join insuranceplan using(uin)
	join insurancecompany ic using(companyID)
	group by companyID),
	total_insurance_patience_ratio as
	(select companyID, (count(companyID)/sum(totalPatients)) as totalpatientcount
	from patientcount
	join insurancecompany ic using(companyID)
	join address using(addressID)
	group by(companyID))
	select count(companyID) as num_insurance_companies, sum(totalPatients) as num_patients, 
	(count(companyID)/sum(totalPatients)) as insurance_patient_ratio,
    (sum(totalpatientcount)/count(companyID)) as avg_insurance_patient_ratio,
	(CASE 
	WHEN (count(companyID)/sum(totalPatients))< (sum(totalpatientcount)/count(companyID)) THEN "RECOMMENDED"
	ELSE "NOT RECOMMENDED"
	END) as RECOMMENDATION
	from total_insurance_patience_ratio
	join patientcount using(companyID)
	join insurancecompany ic using(companyID)
	join address using(addressID)
	where state = req_state;
END
//
DELIMITER ;

select distinct state from address;
 
CALL companySetup("CA");
CALL companySetup("OK");
CALL companySetup("MA");
CALL companySetup("MD");  
CALL companySetup("AL");  
 

