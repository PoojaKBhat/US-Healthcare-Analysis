use healthcare;
 
WITH RankedClaims AS (
    SELECT diseaseName, planName, count(claimID) AS claimCount,
        RANK() OVER (PARTITION BY diseaseName ORDER BY count(claimID) DESC) AS rank_most,
        RANK() OVER (PARTITION BY diseaseName ORDER BY count(claimID)) AS rank_least
    FROM insuranceplan
    JOIN claim USING (uin)
    JOIN treatment USING (claimID)
    JOIN disease USING (diseaseID)
    GROUP BY diseaseName, planName
)
SELECT diseaseName, planName, claimCount,
    CASE
        WHEN rank_most = 1 THEN "Most Claimed"
        WHEN rank_least = 1 THEN "Least Claimed"
    END AS claimCountStatus
FROM RankedClaims
WHERE rank_most = 1 OR rank_least = 1
ORDER BY diseaseName, claimCount DESC;
