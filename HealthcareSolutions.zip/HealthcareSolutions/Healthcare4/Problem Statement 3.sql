use healthcare;

select medicineID, quantity, discount from(
select medicineID, quantity, discount,
(CASE
WHEN quantity >7500 THEN "High Quantity"
WHEN quantity<1000 THEN "Low Quantity"
END) as quantity_type,
(CASE
WHEN discount>=30 THEN "HIGH"
WHEN discount = 0 THEN "NONE"
END) as discount_type
from keep join pharmacy using(pharmacyID)
where pharmacyName='Spot Rx') as q
where (quantity_type = "Low Quantity" and discount_type="High") or (quantity_type = "High Quantity" and discount_type="None");