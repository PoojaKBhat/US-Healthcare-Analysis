use healthcare;

select medicineID,
(CASE
	WHEN productType=1 THEN "Generic"
    WHEN productType=2 THEN "Patent"
    WHEN productType=3 THEN "Reference"
    WHEN productType=4 THEN "Similar"
    WHEN productType=5 THEN "New"
    WHEN productType=6 THEN "Specific"
END) as productType
 from medicine
where (productType in (1,2,3) and taxCriteria='I') or (productType in (4,5,6) and taxCriteria='II');