use healthcare;

select coalesce(d.diseaseName, "GrandTotal") as DiseaseName, coalesce(p.gender,"Total") as Gender, count(t.patientID)
from person p join patient pa on p.personID=pa.patientID
join treatment t on pa.patientID=t.patientID
join disease d on t.diseaseID=d.diseaseID
where YEAR(t.date) =2022
group by d.diseaseName, p.gender with rollup;