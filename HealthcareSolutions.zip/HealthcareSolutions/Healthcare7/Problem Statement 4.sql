use healthcare;

with cte1 as(
	select patientid,
	case 
		when p.dob >= '2005-01-01' and p2.gender = "male" then "YoungMale"
		when p.dob >= '2005-01-01' and p2.gender = "female" then "YoungFemale"
		when p.dob >= '1985-01-01' and p2.gender = "male" then "AdultMale"
		when p.dob >= '1985-01-01' and p2.gender = "female" then "Adultfemale"
		when p.dob >= '1970-01-01' and p2.gender = "male" then "MidAgeMale"
		when p.dob >= '1970-01-01' and p2.gender = "female" then "MidAgeFemale"
		when p2.gender = "male" then "ElderMale"
		when p2.gender = "female" then "ElderFemale"
	end as patient_category
	from patient p 
	join person p2 on p.patientID = p2.personID
),
cte2 as (
	select d.diseasename,c1.patient_category,count(*) as patient_count,
	rank() over(partition by d.diseaseName order by count(*) desc) as categoryrank
	from disease d 
	join treatment t using(diseaseid)
	join cte1 c1 using(patientid)
	group by d.diseaseName,c1.patient_category
)
select diseasename,patient_category,patient_count
from cte2 
where categoryrank<=1;