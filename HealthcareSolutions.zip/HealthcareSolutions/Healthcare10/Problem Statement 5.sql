use healthcare;

create table if not exists Keep_Log(
id int auto_increment primary key,
medicineID int,
quantity int
);

delimiter //
create trigger updatekeeplog
before update
on keep
for each row
BEGIN
	IF old.quantity <> new.quantity THEN
		insert into Keep_Log(medicineID,quantity)
        values(old.medicineID, new.quantity - old.quantity);
    END IF;
END
//
delimiter ;

-- select * from keep;

select * from Keep_Log;

update keep
set quantity = quantity-200
where pharmacyID=3287 and medicineID=21182;

select * from Keep_Log;

update keep
set quantity = quantity+800
where pharmacyID=2060 and medicineID=16517;

select * from Keep_Log;

