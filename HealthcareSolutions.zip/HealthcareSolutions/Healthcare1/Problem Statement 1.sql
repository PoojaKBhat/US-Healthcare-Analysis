use healthcare;

delimiter //
create function get_patients_age_category(dob date, treatment_date date)
returns varchar(20)
READS SQL DATA
BEGIN
	declare age integer;
	set age = TIMESTAMPDIFF(YEAR, dob, treatment_date);
    if age <= 14 then
		return "Children";
	elseif age>=15 AND age<=24 then
		return "Youth";
	elseif age>=25 AND age<=64 then
		return "Adults";
	else
		return "Seniors";
	end if;
END
//
delimiter ;

select get_patients_age_category(dob,date) as Age_Category, count(treatmentID) as No_of_treatments_in_2022
from patient join treatment using(patientID)
where date between '2022-01-01' and '2022-12-31'
group by Age_Category;