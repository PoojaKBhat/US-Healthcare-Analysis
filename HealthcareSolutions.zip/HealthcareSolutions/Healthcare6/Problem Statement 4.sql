use healthcare;

select city, count(personID) as registeredPeopleCount, count(patientID) as patientCount,
((count(patientID)/count(personID))*100) as perc_of_patients
from address join person using (addressID)
left join patient on person.personID=patient.patientID
group by city
having count(personID)>=10;