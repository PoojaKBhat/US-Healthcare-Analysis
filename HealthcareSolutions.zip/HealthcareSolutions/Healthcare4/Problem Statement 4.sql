use healthcare;

with avgmaxprice as
(select avg(maxPrice) as avgPrice from medicine)
select medicineID,costType from (select medicineID, 
(CASE
WHEN maxPrice<(0.5)*avgPrice THEN "Affordable"
WHEN maxPrice>2*avgPrice THEN "Costly"
END) as costType
from avgmaxprice, Medicine
where hospitalExclusive="S" ) as q
where costType is not null;