use healthcare;

select prescriptionID, sum(quantity) as medicine_count,
(CASE
WHEN sum(quantity)<20 THEN "low quantity"
WHEN sum(quantity)>=20 and  sum(quantity)<=49 then "medium quantity"
WHEN sum(quantity)>=50 THEN "high quantity"
END) as Tag
from medicine join contain using(medicineID)
group by prescriptionID;