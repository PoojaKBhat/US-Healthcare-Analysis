use healthcare;

select p.personName, count(t.treatmentID) as treatmentCount, timestampdiff(YEAR,pa.dob,curdate()) as age
from person p join patient pa on p.personID=pa.patientID
join treatment t on pa.patientID = t.patientID
group by p.personID
having count(t.treatmentID)>1
order by treatmentCount desc; 