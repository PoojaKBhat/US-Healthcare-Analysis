use healthcare;

select companyName, planName, count(treatmentID) as treatmentCount
from insurancecompany join insuranceplan using(companyID)
join claim using(uin)
join treatment using(claimID)
group by companyName,planName,uin;