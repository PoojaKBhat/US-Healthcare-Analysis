use healthcare;

DELIMITER //
CREATE PROCEDURE GetGenderwiseReport(IN disease_id INT)
BEGIN
    DECLARE disease_name VARCHAR(255);
    DECLARE number_of_male_treated INT;
    DECLARE number_of_female_treated INT;
    DECLARE more_treated_gender VARCHAR(10);

    -- Get the disease name
    SELECT diseaseName INTO disease_name
    FROM disease
    WHERE diseaseID = disease_id;

    -- Get the number of males treated for the disease
    SELECT COUNT(*) INTO number_of_male_treated
    FROM treatment
    JOIN patient ON treatment.patientID = patient.patientID
	JOIN person on patient.patientID = person.personID
    WHERE treatment.diseaseID = disease_id AND person.gender = 'Male';

    -- Get the number of females treated for the disease
    SELECT COUNT(*) INTO number_of_female_treated
    FROM treatment
    JOIN patient ON treatment.patientID = patient.patientID
    JOIN person on patient.patientID = person.personID
    WHERE treatment.diseaseID = disease_id AND person.gender = 'Female';

    -- Determine the more treated gender
    IF number_of_male_treated > number_of_female_treated THEN
        SET more_treated_gender = 'Male';
    ELSEIF number_of_female_treated > number_of_male_treated THEN
        SET more_treated_gender = 'Female';
    ELSE
        SET more_treated_gender = 'Same';
    END IF;

    -- Return the result
    SELECT disease_name, number_of_male_treated, number_of_female_treated, more_treated_gender;
END
//
DELIMITER ; 


CALL GetGenderwiseReport(15);
CALL GetGenderwiseReport(38);
CALL GetGenderwiseReport(39);
CALL GetGenderwiseReport(40);
