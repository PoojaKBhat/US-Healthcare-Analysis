use healthcare;

select coalesce(IC.companyName,"Grand Total") as CompanyName,coalesce(IP.planName,"Total") as PlanName,
YEAR(t.date) as year,count(c.claimID) as claim_count
from insurancecompany IC join insuranceplan IP on IC.companyID=IP.companyID
join claim c on IP.uin = c.uin
join treatment t on t.claimID=c.claimID
where YEAR(t.date) in (2020, 2021, 2022)
group by IC.companyName, IP.planName, YEAR(t.date) with rollup;