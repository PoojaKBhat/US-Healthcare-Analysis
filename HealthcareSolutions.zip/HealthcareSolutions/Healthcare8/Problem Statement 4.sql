use healthcare;

-- The total quantity of medicine in a prescription is the sum of the quantity of all the medicines in the prescription.
-- Select the prescriptions for which the total quantity of medicine exceeds
-- the avg of the total quantity of medicines for all the prescriptions.

drop table if exists T1;

create table T1(
pharmacyID int,
prescriptionID bigint,
totalQuantity int
);

insert into T1
select Pharmacy.pharmacyID, Prescription.prescriptionID, sum(quantity) as totalQuantity
from Pharmacy
join Prescription on Pharmacy.pharmacyID = Prescription.pharmacyID
join Contain on Contain.prescriptionID = Prescription.prescriptionID
join Medicine on Medicine.medicineID = Contain.medicineID
join Treatment on Treatment.treatmentID = Prescription.treatmentID
where YEAR(date) = 2022
group by Pharmacy.pharmacyID, Prescription.prescriptionID
order by Pharmacy.pharmacyID, Prescription.prescriptionID;


select * from T1
where totalQuantity > (select avg(totalQuantity) from T1);

-- Optimized solution

WITH AvgTotalQuantity AS (
    SELECT AVG(totalQuantity) AS avgQuantity
    FROM (
        SELECT
            Pharmacy.pharmacyID,
            Prescription.prescriptionID,
            SUM(quantity) AS totalQuantity
        FROM
            Pharmacy
            JOIN Prescription ON Pharmacy.pharmacyID = Prescription.pharmacyID
            JOIN Contain ON Contain.prescriptionID = Prescription.prescriptionID
            JOIN Medicine ON Medicine.medicineID = Contain.medicineID
            JOIN Treatment ON Treatment.treatmentID = Prescription.treatmentID
        WHERE
            YEAR(date) = 2022
        GROUP BY
            Pharmacy.pharmacyID, Prescription.prescriptionID
    ) AS Subquery
)

SELECT
    Pharmacy.pharmacyID,
    Prescription.prescriptionID,
    SUM(quantity) AS totalQuantity
FROM
    Pharmacy
    JOIN Prescription ON Pharmacy.pharmacyID = Prescription.pharmacyID
    JOIN Contain ON Contain.prescriptionID = Prescription.prescriptionID
    JOIN Medicine ON Medicine.medicineID = Contain.medicineID
    JOIN Treatment ON Treatment.treatmentID = Prescription.treatmentID
WHERE
    YEAR(date) = 2022
GROUP BY
    Pharmacy.pharmacyID, Prescription.prescriptionID
HAVING
    SUM(quantity) > (SELECT avgQuantity FROM AvgTotalQuantity);
