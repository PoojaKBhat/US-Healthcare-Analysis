use healthcare;

DELIMITER //
CREATE PROCEDURE claimStatus(IN disease_id INT)
BEGIN
    DECLARE avg_claim_count DECIMAL(10, 2);
    DECLARE claim_status VARCHAR(100);

    WITH avgclaimsperdisease AS (
        SELECT diseaseID, COUNT(claimID) AS total_claims_per_disease
        FROM treatment
        JOIN disease USING (diseaseID)
        GROUP BY diseaseID
    )

    SELECT AVG(total_claims_per_disease) INTO avg_claim_count
    FROM avgclaimsperdisease;

    IF (SELECT COUNT(claimID) FROM treatment WHERE diseaseID = disease_id) > avg_claim_count THEN
        SET claim_status = "claimed higher than average";
    ELSE
        SET claim_status = "claimed lower than average";
    END IF;

    SELECT avg_claim_count AS avgClaims, claim_status AS claimStatus;
END
//
DELIMITER ;



-- drop procedure claimStatus
CALL claimStatus(29);
CALL claimStatus(11);
CALL claimStatus(1);
