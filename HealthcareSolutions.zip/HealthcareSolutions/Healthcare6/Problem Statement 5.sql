use healthcare;

select companyName
from medicine
where substanceName like "%ranitidina%"
group by companyName
having count(substanceName)
order by count(substanceName) desc
LIMIT 3;