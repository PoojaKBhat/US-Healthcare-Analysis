use healthcare;

select pharmacyID, pharmacyName, sum(quantity) as quantity, 
sum(CASE 
WHEN hospitalExclusive="S" then quantity
END) as hospital_exclusive_count,
(sum(CASE 
WHEN hospitalExclusive="S" then quantity
END)/sum(quantity))*100 as perc_hosp_excl
from pharmacy join prescription using (pharmacyID)
join contain using(prescriptionID)
join medicine using(medicineID)
join treatment using(treatmentID)
where year(date)=2022
group by pharmacyID
order by perc_hosp_excl desc;