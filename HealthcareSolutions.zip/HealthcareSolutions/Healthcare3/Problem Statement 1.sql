use healthcare;

select pharmacyName, count(prescriptionID) as numOfprescriptions
from pharmacy join prescription using(pharmacyID)
join contain using(prescriptionID)
join medicine using(medicineID)
where hospitalExclusive="S"
group by pharmacyName;