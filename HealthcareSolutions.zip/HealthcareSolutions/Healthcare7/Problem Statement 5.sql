use healthcare;

select companyName ,productName ,description ,maxPrice ,
case 
	when maxprice > 1000 then "pricey"
	when maxprice < 5 then "affordable"
	else "moderate"
end as price_category
from medicine 
where maxPrice > 1000 or maxPrice < 5
order by maxPrice desc;