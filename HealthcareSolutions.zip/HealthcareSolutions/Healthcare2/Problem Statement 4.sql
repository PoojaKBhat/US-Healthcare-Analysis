use healthcare;

select a.addressID, d.diseaseName, count(pa.patientID) as no_of_households
from address a join person p on a.addressID=p.addressID
join patient pa on pa.patientID = p.personID
join treatment t on t.patientID=pa.patientID
join disease d on d.diseaseID=t.diseaseID
group by a.addressID, d.diseaseName
having count(pa.patientID)>1;
