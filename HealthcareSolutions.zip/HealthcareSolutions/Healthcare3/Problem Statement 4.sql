use healthcare;

use healthcare;

select state, count(personID) as registeredPeopleCount, count(patientID) as patientCount,
(round(count(patientID)/count(personID),2)) as people_to_patient_ratio
from address join person using (addressID)
left join patient on person.personID=patient.patientID
group by state
order by people_to_patient_ratio;