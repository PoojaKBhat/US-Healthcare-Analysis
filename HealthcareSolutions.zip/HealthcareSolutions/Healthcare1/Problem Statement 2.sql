use healthcare;

select  D.diseaseName,
sum(case when P.gender = "male" then 1 end) as MALE_COUNT,
sum(case when P.gender = "female" then 1 end) as FEMALE_COUNT,
(CASE
WHEN sum(case when P.gender = "female" then 1 else 0 end) = 0 then "FEMALE_COUNT=0"
else sum(case when P.gender = "male" then 1 else 0 end)/sum(case when P.gender = "female" then 1 else 0 end)
end) as male_to_female_ratio
from person P join patient p1 on P.personID = p1.patientID
join treatment t on t.patientID = p1.patientID
join disease D on D.diseaseID = t.diseaseID
group by  D.diseaseName
order by male_to_female_ratio desc;