use healthcare;

select state, round((count(treatmentID)/count(claimID)),2) as treatment_to_claim_ratio
from address join person using(addressID)
join patient on person.personID=patient.patientID
join treatment using(patientID)
where date between "2021-04-01" and "2022-03-31"
group by state;