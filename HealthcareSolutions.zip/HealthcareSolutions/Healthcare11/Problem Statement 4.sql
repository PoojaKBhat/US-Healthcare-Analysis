use healthcare;

DELIMITER //
create function getcount(cty VARCHAR(20),dN VARCHAR(20), year_value INT) returns INT deterministic
begin 
	declare cnts INT;

	select count(t.treatmentID) into cnts
	from address a join person p on a.addressID  = p.addressID join patient p2 on p.personID = p2.patientID 
	join treatment t on t.patientID = p2.patientID join disease d on d.diseaseID = t.diseaseID
	where a.city = cty and d.diseaseName = dN and YEAR(t.date) = year_value;
    return cnts;
end //
DELIMITER ;

select getcount('Arvada','Cancer',2021);