use healthcare;

select companyName, planName, claimCount,
(CASE
WHEN least_rank=1 THEN "Least Claimed"
WHEN most_rank=1 THEN "Most Claimed"
END) as claimCountStatus
from
(select companyName, planName, count(claimID) as claimCount,
rank() over (partition by companyName order by count(claimID)) as least_rank,
rank() over (partition by companyName order by count(claimID) desc) as most_rank
from insurancecompany join insuranceplan using(companyID)
join claim using(uin)
group by companyName,planName) as sq
where least_rank=1 or most_rank=1;