use healthcare;

select coalesce(a.state,"Grand Total") as State, coalesce(pe.gender, "Total") as Gender, count(t.patientID) as total_patients
from address a join person pe on a.addressID=pe.addressID
join patient pa on pa.patientID=pe.personID
join treatment t on t.patientID=pa.patientID
join disease d on d.diseaseID = t.diseaseID
where d.diseaseName = "Autism"
group by a.state, pe.gender with rollup;