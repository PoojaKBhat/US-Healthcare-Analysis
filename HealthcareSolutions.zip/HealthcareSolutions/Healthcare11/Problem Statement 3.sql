use healthcare;

DELIMITER //
create function getdiseasename(state_param VARCHAR(10), year_value INT) returns varchar(50) deterministic
begin 
	DECLARE diseasename_one VARCHAR(50);

		select diseaseName INTO diseasename_one
		from (select diseaseName, dense_rank() over(partition by state order by cnt desc) as rnk from (select a.state, d.diseaseName, count(d.diseaseID) as cnt
		from address a join person p on a.addressID  = p.addressID join patient p2 on p.personID = p2.patientID 
		join treatment t on t.patientID = p2.patientID join disease d on d.diseaseID = t.diseaseID
		where state = 'AK' and year(t.date) = 2022
		group by a.state, d.diseaseID ) as T1) as T2 where rnk = 1;

	return diseasename_one;
end //
delimiter ;

select getdiseasename('AK',2022);