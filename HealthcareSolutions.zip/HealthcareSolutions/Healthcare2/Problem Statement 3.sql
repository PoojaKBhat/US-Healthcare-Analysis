use healthcare;

select diseaseName, planName, claimCount,
(CASE
WHEN rank_most=1 THEN "Most Claimed"
WHEN rank_least=1 THEN "Least Claimed"
END) as claimCountStatus
from
(select diseaseName, planName, count(claimID) as claimCount,
rank() over (partition by diseaseName order by count(claimID) desc) as rank_most,
rank() over (partition by diseaseName order by count(claimID)) as rank_least
from insuranceplan join claim using(uin)
join treatment using(claimID)
join disease using(diseaseID)
group by diseaseName, planName
order by diseaseName, planName, claimCount desc) as sq 
where rank_most=1 or rank_least=1
order by diseaseName, claimcount desc;