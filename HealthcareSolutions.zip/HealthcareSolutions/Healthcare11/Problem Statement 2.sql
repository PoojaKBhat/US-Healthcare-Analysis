use healthcare;

DELIMITER //

CREATE FUNCTION avg_cost_of_medicines(pharmacy_id INT, year_value INT) 
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    DECLARE avg_price VARCHAR(20);

    SELECT round(avg(m.maxPrice),2) 
    INTO avg_price
    FROM pharmacy p
    JOIN prescription p2 ON p.pharmacyID = p2.pharmacyID
    JOIN contain c ON c.prescriptionID = p2.prescriptionID
    JOIN medicine m ON m.medicineID = c.medicineID
    JOIN treatment t ON t.treatmentID = p2.treatmentID
    WHERE p.pharmacyID = pharmacy_id AND YEAR(t.date) = year_value;

    RETURN avg_price;
END //
DELIMITER ;


-- select * from pharmacy;

SELECT pharmacyName, round(avg(avg_cost_of_medicines(pharmacyID,2022)),2) as average_cost
from pharmacy join prescription using(pharmacyID)
join treatment using(treatmentID)
where year(date)=2022
group by pharmacyName;

-- drop function avg_cost_of_medicines;