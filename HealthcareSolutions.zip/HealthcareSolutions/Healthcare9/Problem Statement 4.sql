use healthcare;

select coalesce(P.PharmacyName,"Grand Total") as PharmacyName, coalesce(D.diseaseName,"Total") as DiseaseName,
count(pr.prescriptionID) as TotalPrescriptionCount
from pharmacy P join prescription pr on P.pharmacyID=pr.pharmacyID
join treatment t on pr.treatmentID=t.treatmentID
join disease d on t.diseaseID=d.diseaseID
where YEAR(t.date) = 2022
group by P.PharmacyName, D.diseaseName with rollup;